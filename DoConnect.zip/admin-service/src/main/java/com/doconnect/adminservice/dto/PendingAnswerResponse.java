package com.doconnect.adminservice.dto;

import lombok.Data;

@Data
public class PendingAnswerResponse {
    private Long id;
    private Long questionId;
    private String content;
    private String username;
    private String createdAt;
}
