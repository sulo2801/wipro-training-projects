package com.doconnect.adminservice.dto;

import lombok.Data;

@Data
public class QuestionResponse {
    private Long id;
    private String title;
    private String content;
    private String userId;
    private String status;
    private boolean approved;
    private boolean active;
    private String createdAt;
}
