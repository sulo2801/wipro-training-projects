package com.doconnect.adminservice.service;

import java.util.List;
import com.doconnect.adminservice.dto.UserAdminResponse;

public interface AdminActionService {

    List<UserAdminResponse> getAllUsers();
    String deactivateUser(Long id);

    String approveQuestion(Long id);
    String deleteQuestion(Long id);
    String closeDiscussion(Long id);

    String approveAnswer(Long id);
    String deleteAnswer(Long id);

    String getPendingQuestions();
    String getPendingAnswers();

    String getAnalytics();

    String getActivityLog();
}
