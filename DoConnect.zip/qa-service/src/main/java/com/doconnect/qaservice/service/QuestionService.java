package com.doconnect.qaservice.service;

import java.util.List;
import java.util.Map;

import com.doconnect.qaservice.dto.QuestionResponse;
import com.doconnect.qaservice.dto.AnswerResponse;

public interface QuestionService {

    // ========================= USER =========================
    QuestionResponse askQuestion(String title, String content, String userId);

    AnswerResponse addAnswer(Long questionId, String content, String userId);

    List<QuestionResponse> getAllApprovedActiveQuestions();

    List<AnswerResponse> getAnswersForQuestion(Long id);

    List<QuestionResponse> searchQuestions(String keyword);

    // ========================= ADMIN =========================
    void approveQuestion(Long id);

    void approveAnswer(Long id);

    List<QuestionResponse> getPendingQuestions();

    List<AnswerResponse> getPendingAnswers();

    void closeDiscussion(Long id);

    void deleteAnswer(Long id);

    // 🔹 NEW: delete a question (used by Admin-Service)
    void deleteQuestion(Long id);

    // ========================= LIKE / DISLIKE =========================
    void likeAnswer(Long answerId, String userId);

    void unlikeAnswer(Long answerId, String userId);

    // ========================= ANALYTICS =========================
    Map<String, Object> getAdminAnalytics();

    // ========================= ACTIVITY LOGS =========================
    List<String> getAdminLogs();
    
    List<QuestionResponse> getAllQuestions();

}
