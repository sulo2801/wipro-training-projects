package com.doconnect.userservice.service;

import java.util.List;

import com.doconnect.userservice.dto.AuthResponse;
import com.doconnect.userservice.dto.LoginRequest;
import com.doconnect.userservice.dto.RegisterRequest;
import com.doconnect.userservice.dto.UserResponse;
import com.doconnect.userservice.dto.UserAdminResponse;


public interface UserService {

    // ===================== AUTH =====================
    AuthResponse register(RegisterRequest request);
    AuthResponse login(LoginRequest request);
    void logout(String token);
    void loadUser(String username);

    // ===================== USER OPS =====================
    UserResponse getUserById(Long id);

    // ⭐ REQUIRED FOR ADMIN PANEL
    List<UserAdminResponse> getAllUsersForAdmin();

    // ⭐ Required for admin to deactivate user
    void deactivateUser(Long id);
}
