package com.doconnect.adminservice.service;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.doconnect.adminservice.dto.AuthResponse;
import com.doconnect.adminservice.dto.LoginRequest;
import com.doconnect.adminservice.dto.RegisterRequest;
import com.doconnect.adminservice.entity.Admin;
import com.doconnect.adminservice.repository.AdminRepository;
import com.doconnect.adminservice.security.JwtUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {

    private final AdminRepository adminRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;
    private final AdminDetailsService adminDetailsService;

    // -----------------------------
    //      REGISTER ADMIN
    // -----------------------------
    @Override
    public void register(RegisterRequest request) {

        // Check if admin already exists using EMAIL
        if (adminRepository.findByUsername(request.getEmail()).isPresent()) {
            throw new IllegalArgumentException("Admin already exists");
        }

        Admin admin = Admin.builder()
                .username(request.getEmail())     // Email used as username
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role("ADMIN")
                .active(true)
                .build();

        adminRepository.save(admin);
    }

    // -----------------------------
    //      LOGIN ADMIN
    // -----------------------------
    @Override
    public AuthResponse login(LoginRequest request) {

        Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(
                    request.getEmail(),         // using email as username
                    request.getPassword()
            )
        );

        if (!authentication.isAuthenticated()) {
            throw new RuntimeException("Invalid email or password");
        }

        // Load admin details
        UserDetails userDetails =
                adminDetailsService.loadUserByUsername(request.getEmail());

        // Generate JWT token
        String token = jwtUtil.generateToken(userDetails);

        return new AuthResponse(token, "Login successful");
    }
}
