package com.doconnect.qaservice.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.doconnect.qaservice.dto.AnswerRequest;
import com.doconnect.qaservice.dto.AnswerResponse;
import com.doconnect.qaservice.dto.QuestionRequest;
import com.doconnect.qaservice.dto.QuestionResponse;
import com.doconnect.qaservice.service.QuestionService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/qa")
@RequiredArgsConstructor
public class QuestionController {

    private final QuestionService questionService;

    // ========================== USER PART ==========================
    @PostMapping("/questions")
    public ResponseEntity<QuestionResponse> askQuestion(
            Authentication authentication,
            @RequestBody QuestionRequest request
    ) {
        if (authentication == null || authentication.getName() == null)
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(questionService.askQuestion(
                        request.getTitle(),
                        request.getContent(),
                        authentication.getName()
                ));
    }

    @GetMapping("/questions")
    public ResponseEntity<List<QuestionResponse>> getAllQuestions() {
        return ResponseEntity.ok(questionService.getAllQuestions());
    }

    @GetMapping("/questions/search")
    public ResponseEntity<List<QuestionResponse>> searchQuestions(@RequestParam("q") String keyword) {
        return ResponseEntity.ok(questionService.searchQuestions(keyword));
    }

    @PostMapping("/answers")
    public ResponseEntity<AnswerResponse> addAnswer(
            Authentication authentication,
            @RequestBody AnswerRequest request
    ) {
        if (authentication == null || authentication.getName() == null)
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        return ResponseEntity.status(HttpStatus.CREATED).body(
                questionService.addAnswer(request.getQuestionId(), request.getContent(), authentication.getName())
        );
    }

    @GetMapping("/questions/{id}/answers")
    public ResponseEntity<List<AnswerResponse>> getAnswers(@PathVariable Long id) {
        return ResponseEntity.ok(questionService.getAnswersForQuestion(id));
    }

    @PostMapping("/answers/{id}/like")
    public ResponseEntity<Void> likeAnswer(Authentication auth, @PathVariable Long id) {
        if (auth == null || auth.getName() == null)
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        questionService.likeAnswer(id, auth.getName());
        return ResponseEntity.ok().build();
    }

    @PostMapping("/answers/{id}/dislike")
    public ResponseEntity<Void> dislikeAnswer(Authentication auth, @PathVariable Long id) {
        if (auth == null || auth.getName() == null)
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        questionService.unlikeAnswer(id, auth.getName());
        return ResponseEntity.ok().build();
    }


    // =============================== ADMIN PART FIXED ===============================

    // ---- Pending Questions ----
    @GetMapping("/admin/questions/pending")
    public ResponseEntity<List<QuestionResponse>> getPendingQuestions() {
        return ResponseEntity.ok(questionService.getPendingQuestions());
    }

    // ---- Pending Answers ----
    @GetMapping("/admin/answers/pending")
    public ResponseEntity<List<AnswerResponse>> getPendingAnswers() {
        return ResponseEntity.ok(questionService.getPendingAnswers());
    }

    // ---- Approve Question ----
    @PutMapping("/admin/questions/{id}/approve")
    public ResponseEntity<Void> approveQuestion(@PathVariable Long id) {
        questionService.approveQuestion(id);
        return ResponseEntity.ok().build();
    }

    // ---- Approve Answer ----
    @PutMapping("/admin/answers/{id}/approve")
    public ResponseEntity<Void> approveAnswer(@PathVariable Long id) {
        questionService.approveAnswer(id);
        return ResponseEntity.ok().build();
    }

    // ---- Close Discussion ----
    @PutMapping("/admin/discussions/{id}/close")
    public ResponseEntity<Void> closeDiscussionAdmin(@PathVariable Long id) {
        questionService.closeDiscussion(id);
        return ResponseEntity.ok().build();
    }

    // ---- DELETE QUESTION (FIXED PATH) ----
    @DeleteMapping("/admin/questions/{id}")
    public ResponseEntity<Void> deleteQuestion(@PathVariable Long id) {
        questionService.deleteQuestion(id);
        return ResponseEntity.ok().build();
    }

    // ---- DELETE ANSWER (FIXED PATH) ----
    @DeleteMapping("/admin/answers/{id}")
    public ResponseEntity<Void> deleteAnswer(@PathVariable Long id) {
        questionService.deleteAnswer(id);
        return ResponseEntity.ok().build();
    }

    // ---- Analytics ----
    @GetMapping("/admin/analytics")
    public ResponseEntity<?> getAnalytics() {
    	System.out.println("anal");
        return ResponseEntity.ok(questionService.getAdminAnalytics());
    }

    // ---- Logs ----
    @GetMapping("/admin/logs")
    public ResponseEntity<?> getLogs() {
        return ResponseEntity.ok(questionService.getAdminLogs());
    }
}
