package com.doconnect.qaservice.service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.doconnect.qaservice.client.UserClient;
import com.doconnect.qaservice.client.UserResponse;
import com.doconnect.qaservice.dto.AnswerResponse;
import com.doconnect.qaservice.dto.QuestionResponse;
import com.doconnect.qaservice.entity.Answer;
import com.doconnect.qaservice.entity.AnswerLike;
import com.doconnect.qaservice.entity.Question;
import com.doconnect.qaservice.entity.QuestionStatus;
import com.doconnect.qaservice.repository.AnswerLikeRepository;
import com.doconnect.qaservice.repository.AnswerRepository;
import com.doconnect.qaservice.repository.QuestionRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class QuestionServiceImpl implements QuestionService {

    private final QuestionRepository questionRepository;
    private final AnswerRepository answerRepository;
    private final UserClient userClient;
    private final AnswerLikeRepository likeRepository;

    // ===========================================================
    // ASK QUESTION
    // ===========================================================
    @Override
    public QuestionResponse askQuestion(String title, String content, String userId) {

        Question q = Question.builder()
                .title(title)
                .content(content)
                .userId(userId)
                .createdAt(LocalDateTime.now())
                .status(QuestionStatus.PENDING)
                .approved(false)
                .active(true)
                .build();

        return toQuestionResponse(questionRepository.save(q));
    }

    // ===========================================================
    // ADD ANSWER
    // ===========================================================
    @Override
    public AnswerResponse addAnswer(Long questionId, String content, String userId) {

        Question q = questionRepository.findById(questionId)
                .orElseThrow(() -> new RuntimeException("Question not found"));

        Answer a = Answer.builder()
                .question(q)
                .content(content)
                .userId(userId)
                .approved(false)
                .active(true)
                .createdAt(LocalDateTime.now())
                .build();

        return toAnswerResponse(answerRepository.save(a));
    }

 // ===========================================================
    // ADMIN APPROVE QUESTION
    // ===========================================================
    @Override
    public void approveQuestion(Long id) {
        Question q = questionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Invalid question ID"));

        q.setApproved(true);
        q.setActive(true);
        q.setStatus(QuestionStatus.APPROVED);

        questionRepository.save(q);
    }

    // ===========================================================
    // ADMIN APPROVE ANSWER
    // ===========================================================
    @Override
    public void approveAnswer(Long id) {
        Answer a = answerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Invalid answer ID"));

        a.setApproved(true);
        a.setActive(true);

        answerRepository.save(a);
    }

    // ===========================================================
    // CLOSE DISCUSSION
    // ===========================================================
    @Override
    public void closeDiscussion(Long id) {
        Question q = questionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Invalid question ID"));

        q.setStatus(QuestionStatus.RESOLVED);
        questionRepository.save(q);
    }

    // ===========================================================
    // DELETE ANSWER
    // ===========================================================
    @Override
    public void deleteAnswer(Long id) {
        Answer a = answerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Invalid answer ID"));

        a.setActive(false);
        answerRepository.save(a);
    }

    // 🔹 NEW: DELETE QUESTION (soft delete)
    @Override
    public void deleteQuestion(Long id) {
        Question q = questionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Invalid question ID"));

        q.setActive(false);        // soft delete so history remains
        questionRepository.save(q);
    }

    // ===========================================================
    // GET APPROVED QUESTIONS
    // ===========================================================
    @Override
    public List<QuestionResponse> getAllApprovedActiveQuestions() {
        return questionRepository.findAll()
                .stream()
                .filter(q -> q.isActive() && q.isApproved())
                .map(this::toQuestionResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<QuestionResponse> getAllQuestions() {
        return questionRepository.findAll()
                .stream()
                .filter(Question::isActive)
                .map(this::toQuestionResponse)
                .collect(Collectors.toList());
    }



    // ===========================================================
    // GET ANSWERS FOR QUESTION
    // ===========================================================
    @Override
    public List<AnswerResponse> getAnswersForQuestion(Long id) {
        return answerRepository.findByQuestionIdAndActiveTrue(id)
                .stream().map(this::toAnswerResponse)
                .collect(Collectors.toList());
    }

    // ===========================================================
    // SEARCH QUESTIONS
    // ===========================================================
    @Override
    public List<QuestionResponse> searchQuestions(String keyword) {
        return questionRepository.searchByKeyword(keyword)
                .stream()
                .filter(Question::isActive)
                .map(this::toQuestionResponse)
                .collect(Collectors.toList());
    }

    // ===========================================================
    // ADMIN — PENDING
    // ===========================================================
    @Override
    public List<QuestionResponse> getPendingQuestions() {
        return questionRepository.findByStatus(QuestionStatus.PENDING)
                .stream().map(this::toQuestionResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<AnswerResponse> getPendingAnswers() {
        return answerRepository.findByApprovedFalseAndActiveTrue()
                .stream().map(this::toAnswerResponse)
                .collect(Collectors.toList());
    }

    // ===========================================================
    // LIKE / UNLIKE
    // ===========================================================
    @Override
    public void likeAnswer(Long answerId, String userId) {

        boolean exists = likeRepository.findByAnswerIdAndUserId(answerId, userId).isPresent();
        if (exists) return;

        Answer answer = answerRepository.findById(answerId)
                .orElseThrow(() -> new RuntimeException("Answer not found"));

        AnswerLike like = AnswerLike.builder()
                .answer(answer)
                .userId(userId)
                .createdAt(LocalDateTime.now())
                .build();

        likeRepository.save(like);
    }

    @Override
    public void unlikeAnswer(Long answerId, String userId) {
        likeRepository.findByAnswerIdAndUserId(answerId, userId)
                .ifPresent(likeRepository::delete);
    }

    // ===========================================================
    // RESPONSE MAPPERS
    // ===========================================================
    private QuestionResponse toQuestionResponse(Question q) {
        return QuestionResponse.builder()
                .id(q.getId())
                .title(q.getTitle())
                .content(q.getContent())
                .userId(q.getUserId())
                .username(resolveUsername(q.getUserId()))
                .createdAt(q.getCreatedAt())
                .status(q.getStatus())
                .approved(q.isApproved())
                .active(q.isActive())
                .build();
    }

    private AnswerResponse toAnswerResponse(Answer a) {
        int likeCount = 0;
        if (a.getLikes() != null) {
            likeCount = a.getLikes().size();
        }

        return AnswerResponse.builder()
                .id(a.getId())
                .questionId(a.getQuestion().getId())
                .content(a.getContent())
                .userId(a.getUserId())
                .username(resolveUsername(a.getUserId()))
                .createdAt(a.getCreatedAt())
                .approved(a.isApproved())
                .active(a.isActive())
                .likes(likeCount)
                .build();
    }

    // ===========================================================
    // Fetch username from USER-SERVICE
    // ===========================================================
    private String resolveUsername(String userId) {
        try {
            Long id = Long.parseLong(userId);
            UserResponse response = userClient.getUserById(id);

            return response != null ? response.getUsername() : "User-" + userId;

        } catch (Exception e) {
            return "User-" + userId;
        }
    }

    // ===========================================================
    // ADMIN ANALYTICS
    // ===========================================================
    @Override
    public Map<String, Object> getAdminAnalytics() {

        Map<String, Object> map = new HashMap<>();
        map.put("pendingQuestions", questionRepository.countByStatus(QuestionStatus.PENDING));
        map.put("pendingAnswers", answerRepository.countByApprovedFalseAndActiveTrue());
        map.put("totalQuestions", questionRepository.count());
        map.put("totalAnswers", answerRepository.count());

        return map;
    }

    @Override
    public List<String> getAdminLogs() {
        return List.of();
    }
}