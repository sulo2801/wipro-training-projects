package com.doconnect.adminservice.dto;

import lombok.Data;

@Data
public class PendingQuestionResponse {
    private Long id;
    private String title;
    private String content;
    private String username;
    private String createdAt;
}
