package com.doconnect.adminservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.doconnect.adminservice.security.AdminJwtCaptureFilter;
import com.doconnect.adminservice.security.JwtAuthenticationFilter;
import com.doconnect.adminservice.service.AdminDetailsService;

import lombok.RequiredArgsConstructor;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final AdminDetailsService adminDetailsService;
    private final AdminJwtCaptureFilter adminJwtCaptureFilter;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http
            // CSRF must be disabled for stateless JWT APIs
            .csrf(AbstractHttpConfigurer::disable)

            // 🔥 Every request must be stateless (no session stored)
            .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

            // 🔐 URL access rules
            .authorizeHttpRequests(auth -> auth

                // Public endpoints (only login & register should be public)
                .requestMatchers(
                    "/admin/auth/login",
                    "/admin/auth/register",
                    "/admin/auth/logout",
                    "/css/**", "/js/**", "/images/**"
                ).permitAll()

                // All other URLs require ADMIN role
                .anyRequest().hasRole("ADMIN")
            )

            // ⭐ Use our custom AuthenticationProvider
            .authenticationProvider(authenticationProvider())

            // ⭐ FIRST — Extract token from API Gateway header
            .addFilterBefore(adminJwtCaptureFilter, UsernamePasswordAuthenticationFilter.class)

            // ⭐ SECOND — Validate token and set SecurityContext
            .addFilterAfter(jwtAuthenticationFilter, AdminJwtCaptureFilter.class);

        return http.build();
    }

    // Loads admin details from DB + password encoder
    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(adminDetailsService); // load admin from DB
        provider.setPasswordEncoder(passwordEncoder());      // compare encrypted passwords
        return provider;
    }

    // BCrypt hashing for admin passwords
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // Used for authentication manager
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config)
            throws Exception {
        return config.getAuthenticationManager();
    }
}
