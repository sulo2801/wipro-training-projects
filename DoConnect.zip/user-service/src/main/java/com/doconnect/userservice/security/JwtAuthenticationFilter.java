package com.doconnect.userservice.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.Claims;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtUtil jwtUtil;

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain chain
    ) throws ServletException, IOException {

        String header = request.getHeader("Authorization");

        // -------------------------------------------------------------------
        // If token is missing or does not start with "Bearer ", skip filter
        // -------------------------------------------------------------------
        if (header == null || !header.startsWith("Bearer ")) {
            chain.doFilter(request, response);
            return;
        }

        // Extract actual token string
        String token = header.substring(7);

        try {
            // -------------------------------------------------------------------
            // Extract username (subject) from token
            // This is the USERNAME stored by User-Service
            // -------------------------------------------------------------------
            String username = jwtUtil.extractUsername(token);

            // -------------------------------------------------------------------
            // Extract all claims from token
            // -------------------------------------------------------------------
            Claims claims = jwtUtil.extractAllClaims(token);

            // -------------------------------------------------------------------
            // ROLE HANDLING
            // User-Service provides:
            //   "role":  "USER"                 (old format)
            //   "roles": ["ROLE_USER"]          (new format)
            //
            // We support both for compatibility.
            // -------------------------------------------------------------------
            List<String> roles = claims.get("roles", List.class);

            if (roles == null) {
                // Try old "role" claim
                String r = claims.get("role", String.class);

                if (r != null) {
                    roles = List.of(r);    // convert single role → list
                }
            }

            // If roles are STILL missing → default to USER
            if (roles == null) {
                roles = List.of("USER");
            }

            // -------------------------------------------------------------------
            // Convert roles to Spring Security authorities
            // Ensures USER → ROLE_USER
            // -------------------------------------------------------------------
            List<SimpleGrantedAuthority> authorities =
                    roles.stream()
                            .map(r -> r.startsWith("ROLE_") ? r : "ROLE_" + r)
                            .map(SimpleGrantedAuthority::new)
                            .collect(Collectors.toList());

            // -------------------------------------------------------------------
            // Set authentication into Spring context
            // No password needed (null)
            // -------------------------------------------------------------------
            UsernamePasswordAuthenticationToken auth =
                    new UsernamePasswordAuthenticationToken(
                            username,
                            null,
                            authorities
                    );

            SecurityContextHolder.getContext().setAuthentication(auth);

        } catch (Exception e) {
            System.out.println("USER JWT Error: " + e.getMessage());
        }

        // -------------------------------------------------------------------
        // Always continue the filter chain
        // -------------------------------------------------------------------
        chain.doFilter(request, response);
    }
}
