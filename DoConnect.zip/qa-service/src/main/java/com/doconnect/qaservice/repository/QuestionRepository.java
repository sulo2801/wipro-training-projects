package com.doconnect.qaservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.doconnect.qaservice.entity.Question;
import com.doconnect.qaservice.entity.QuestionStatus;

public interface QuestionRepository extends JpaRepository<Question, Long> {

    // Get only APPROVED + ACTIVE questions
    List<Question> findByStatusAndActiveTrue(QuestionStatus status);

    // Pending questions (status = PENDING)
    List<Question> findByStatus(QuestionStatus status);

    // Search questions by keyword
    @Query("SELECT q FROM Question q WHERE LOWER(q.title) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
            "OR LOWER(q.content) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Question> searchByKeyword(String keyword);

    // Count pending questions
    long countByStatus(QuestionStatus status);
}
