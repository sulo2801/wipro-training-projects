package com.doconnect.qaservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.doconnect.qaservice.entity.Answer;
import com.doconnect.qaservice.entity.AnswerComment;

public interface AnswerCommentRepository extends JpaRepository<AnswerComment, Long> {

    List<AnswerComment> findByAnswer(Answer answer);
}
