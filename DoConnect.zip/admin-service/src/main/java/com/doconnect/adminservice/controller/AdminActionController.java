package com.doconnect.adminservice.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.doconnect.adminservice.dto.UserAdminResponse;
import com.doconnect.adminservice.service.AdminActionService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminActionController {

    private final AdminActionService service;

    // ========================= USER OPERATIONS ==============================
    @GetMapping("/users")
    public ResponseEntity<List<UserAdminResponse>> getAllUsers() {
        return ResponseEntity.ok(service.getAllUsers());
    }

    @PutMapping("/users/{id}/deactivate")
    public ResponseEntity<String> deactivateUser(@PathVariable Long id) {
        return ResponseEntity.ok(service.deactivateUser(id));
    }

    // ======================== QUESTION OPS ==================================
    @PutMapping("/questions/{id}/approve")
    public ResponseEntity<String> approveQuestion(@PathVariable Long id) {
        return ResponseEntity.ok(service.approveQuestion(id));
    }

    @DeleteMapping("/questions/{id}")
    public ResponseEntity<String> deleteQuestion(@PathVariable Long id) {
        return ResponseEntity.ok(service.deleteQuestion(id));
    }

    @PutMapping("/questions/{id}/close")
    public ResponseEntity<String> closeDiscussion(@PathVariable Long id) {
        return ResponseEntity.ok(service.closeDiscussion(id));
    }

    // ========================= ANSWER OPS ====================================
    @PutMapping("/answers/{id}/approve")
    public ResponseEntity<String> approveAnswer(@PathVariable Long id) {
        return ResponseEntity.ok(service.approveAnswer(id));
    }

    @DeleteMapping("/answers/{id}")
    public ResponseEntity<String> deleteAnswer(@PathVariable Long id) {
        return ResponseEntity.ok(service.deleteAnswer(id));
    }

    // ======================== PENDING =========================================
    @GetMapping("/questions/pending")
    public ResponseEntity<?> pendingQuestions() {
        return ResponseEntity.ok(service.getPendingQuestions());
    }

    @GetMapping("/answers/pending")
    public ResponseEntity<?> pendingAnswers() {
        return ResponseEntity.ok(service.getPendingAnswers());
    }

    // ======================== ANALYTICS & LOGS ===============================
    @GetMapping("/analytics")
    public ResponseEntity<?> getAnalytics() {
        return ResponseEntity.ok(service.getAnalytics());
    }

    @GetMapping("/logs")
    public ResponseEntity<?> getActivityLogs() {
        return ResponseEntity.ok(service.getActivityLog());
    }
}
