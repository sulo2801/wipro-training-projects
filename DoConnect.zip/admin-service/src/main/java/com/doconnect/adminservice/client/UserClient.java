package com.doconnect.adminservice.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

@FeignClient(name = "USER-SERVICE")
public interface UserClient {

    @GetMapping("/auth/admin/users")
    String getAllUsers();

    @PutMapping("/auth/admin/users/{id}/deactivate")
    String deactivateUser(@PathVariable Long id);
}
