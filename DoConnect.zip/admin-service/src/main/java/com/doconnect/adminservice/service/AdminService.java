package com.doconnect.adminservice.service;

import com.doconnect.adminservice.dto.AuthResponse;
import com.doconnect.adminservice.dto.LoginRequest;
import com.doconnect.adminservice.dto.RegisterRequest;

public interface AdminService {

    void register(RegisterRequest request);

    AuthResponse login(LoginRequest request);
}
