package com.doconnect.qaservice.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.doconnect.qaservice.entity.AnswerLike;

public interface AnswerLikeRepository extends JpaRepository<AnswerLike, Long> {

    Optional<AnswerLike> findByAnswerIdAndUserId(Long answerId, String userId);

    int countByAnswerId(Long answerId);
}
