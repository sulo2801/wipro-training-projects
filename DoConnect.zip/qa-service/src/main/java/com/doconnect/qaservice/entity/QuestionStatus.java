package com.doconnect.qaservice.entity;

public enum QuestionStatus {
	PENDING,
    APPROVED,
    OPEN,
    RESOLVED,
    CLOSED
}
