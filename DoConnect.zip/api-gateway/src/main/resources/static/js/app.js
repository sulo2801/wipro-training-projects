// ======================================================
//  BASE URLs - All calls go through API Gateway (8080)
// ======================================================
const USER_BASE = "http://localhost:8080/auth";
const ADMIN_BASE = "http://localhost:8080/admin";
const QA_BASE = "http://localhost:8080/qa";

// ======================================================
//  SESSION / TOKEN / ROLE
// ======================================================
function saveAuth(token, role) {
    localStorage.setItem("token", token);
    localStorage.setItem("role", role);
}

function getToken() {
    return localStorage.getItem("token");
}

function getRole() {
    return localStorage.getItem("role");
}

async function logout() {
    const token = getToken();
    const role = getRole();

    if (token) {
        const base = role === "ADMIN" ? ADMIN_BASE : USER_BASE;

        try {
            await fetch(`${base}/auth/logout`, {
                method: "POST",
                headers: {
                    "Authorization": `Bearer ${token}`
                }
            });
        } catch (e) {
            console.warn("Logout API failed:", e);
        }
    }

    localStorage.clear();

    if (role === "ADMIN") {
        window.location.href = "/admin/login";
    } else {
        window.location.href = "/login";
    }
}


function authHeaders(json = true) {
    const token = getToken();
    const h = {};
    if (token) h["Authorization"] = `Bearer ${token}`;
    if (json) h["Content-Type"] = "application/json";
    return h;
}

async function safeJson(res) {
    try { return await res.json(); } catch { return null; }
}

function escapeHtml(str) {
    if (!str) return "";
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}


// ======================================================
//  USER REGISTER
// ======================================================
async function userRegister(event) {
    event.preventDefault();

    const payload = {
        username: document.getElementById("username").value,
        password: document.getElementById("password").value
    };

    try {
        const res = await fetch(`${USER_BASE}/register`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const data = await safeJson(res);

        if (res.ok) {
            alert("User registered successfully");
            window.location.href = "/login";
        } else {
            alert(data?.message || "Registration failed");
        }
    } catch (e) {
        alert("Server error: " + e);
    }
}

// ======================================================
//  USER LOGIN
// ======================================================
async function userLogin(event) {
    event.preventDefault();

    const payload = {
        username: document.getElementById("username").value.trim(),
        password: document.getElementById("password").value.trim()
    };

    try {
        const res = await fetch(`${USER_BASE}/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const data = await safeJson(res);

        if (res.ok) {
            saveAuth(data.token, "USER");
            window.location.href = "/dashboard";
        } else {
            alert(data?.message || "Invalid login");
        }
    } catch (e) {
        alert("Server error: " + e);
    }
}

// ======================================================
//  ADMIN REGISTER
// ======================================================
async function adminRegister(event) {
    event.preventDefault();

    const payload = {
        name: document.getElementById("admin-name").value,
        email: document.getElementById("admin-email").value,
        password: document.getElementById("admin-password").value
    };

    try {
        const res = await fetch(`${ADMIN_BASE}/auth/register`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const data = await safeJson(res);

        if (res.ok) {
            alert("Admin registered successfully");
            window.location.href = "/admin/login";
        } else {
            alert(data?.message || "Admin registration failed");
        }
    } catch (e) {
        alert("Server error: " + e);
    }
}

// ======================================================
//  ADMIN LOGIN
// ======================================================
async function adminLogin(event) {
    event.preventDefault();

    const payload = {
        email: document.getElementById("adminEmail").value.trim(),
        password: document.getElementById("adminPassword").value.trim()
    };

    try {
        const res = await fetch(`${ADMIN_BASE}/auth/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const data = await safeJson(res);

        if (res.ok) {
            saveAuth(data.token, "ADMIN");
            window.location.href = "/admin/dashboard";
        } else {
            alert(data?.message || "Invalid admin credentials");
        }
    } catch (e) {
        alert("Server error: " + e);
    }
}


// ======================================================
//  USER: ASK QUESTION
// ======================================================
async function askQuestion(event) {
    event.preventDefault();

    const payload = {
        title: document.getElementById("title").value,
        content: document.getElementById("content").value
    };

    try {
        const res = await fetch(`${QA_BASE}/questions`, {
            method: "POST",
            headers: authHeaders(true),
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            alert("Question submitted for approval");
            window.location.href = "/dashboard";
        } else {
            alert("Failed to submit question");
        }
    } catch (e) {
        alert("Error submitting question: " + e);
    }
}


// ========================================================================
// USER — LIST QUESTIONS
// ========================================================================
let allQuestions = [];

async function loadQuestions() {
    try {
        const res = await fetch(`${QA_BASE}/questions`, {
            headers: authHeaders(false)
        });

        const data = await safeJson(res);

        if (!Array.isArray(data)) return;

        allQuestions = data;
        renderQuestions(allQuestions);

        allQuestions.forEach(q => loadAnswersForQuestion(q.id, true));

    } catch (e) {
        console.error(e);
    }
}

function renderQuestions(list) {
    const box = document.getElementById("questionsBox");
    if (!box) return;

    box.innerHTML = "";

    if (!list || list.length === 0) {
        box.innerHTML = "<p class='text-secondary'>No questions found.</p>";
        return;
    }

    list.forEach(q => {
        const badge =
            !q.approved ? `<span class="badge bg-warning">Pending</span>` :
            q.status === "RESOLVED" ? `<span class="badge bg-success">Resolved</span>` :
            `<span class="badge bg-info">Open</span>`;

        box.innerHTML += `
            <div class="question-card">
                <h5>${escapeHtml(q.title)} ${badge}</h5>
                <p>${escapeHtml(q.content)}</p>
                <p class="question-meta">
                    Posted by: ${escapeHtml(q.username || "Unknown")} • 
                    <span id="answer-count-${q.id}">Answers: 0</span>
                </p>
                <button class="btn btn-pill btn-outline-light-soft"
                    onclick="window.location.href='/answer-question?id=${q.id}'">
                    Answer
                </button>
                <div id="answers-${q.id}" class="mt-3"></div>
            </div>
        `;
    });
}


// ========================================================================
// USER — ANSWERING A QUESTION
// ========================================================================
function loadQuestionForAnswer() {
    const id = new URLSearchParams(window.location.search).get("id");
    if (!id) return;

    localStorage.setItem("answer_question_id", id);

    const box = document.getElementById("questionBox");
    if (box) {
        box.innerHTML = `<h4>Answering Question #${id}</h4>`;
    }
}

async function submitAnswer(event) {
    event.preventDefault();

    const qid = localStorage.getItem("answer_question_id");
    const text = document.getElementById("answerText").value.trim();

    const payload = { questionId: Number(qid), content: text };

    try {
        const res = await fetch(`${QA_BASE}/answers`, {
            method: "POST",
            headers: authHeaders(true),
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            alert("Answer submitted for approval");
            window.location.href = "/view-questions";
        } else {
            alert("Failed to submit answer");
        }
    } catch (e) {
        alert("Error submitting answer: " + e);
    }
}


// ========================================================================
// USER — LOAD ANSWERS
// ========================================================================
async function loadAnswersForQuestion(questionId, updateCount = false) {
    try {
        const res = await fetch(`${QA_BASE}/questions/${questionId}/answers`, {
            headers: authHeaders(false)
        });

        const answers = await safeJson(res);
        const box = document.getElementById(`answers-${questionId}`);

        if (updateCount) {
            const span = document.getElementById(`answer-count-${questionId}`);
            if (span) span.innerText = `Answers: ${answers?.length ?? 0}`;
        }

        if (!box) return;

        if (!answers || answers.length === 0) {
            box.innerHTML = "<p class='question-meta'>No answers yet.</p>";
            return;
        }

        box.innerHTML = answers
            .map(a => `
                <div class="answer-card">
                    <p>${escapeHtml(a.content)}</p>
                    <p class="question-meta">
                        Answered by: ${escapeHtml(a.username || "Unknown")}
                        • Likes: <span id="like-count-${a.id}">${a.likes}</span>
                    </p>
                    <button class="btn btn-sm btn-primary-soft" onclick="likeAnswer(${a.id})">Like</button>
                    <button class="btn btn-sm btn-outline-light-soft" onclick="dislikeAnswer(${a.id})">Dislike</button>
                </div>
            `)
            .join("");

    } catch (e) {
        console.error(e);
    }
}


// ========================================================================
// USER — LIKE & DISLIKE ANSWERS
// ========================================================================
async function likeAnswer(id) {
    await fetch(`${QA_BASE}/answers/${id}/like`, {
        method: "POST",
        headers: authHeaders(false)
    });
    updateAnswerLikes(id);
}

async function dislikeAnswer(id) {
    await fetch(`${QA_BASE}/answers/${id}/dislike`, {
        method: "POST",
        headers: authHeaders(false)
    });
    updateAnswerLikes(id);
}

async function updateAnswerLikes(id) {
    try {
        const res = await fetch(`${QA_BASE}/questions`, { headers: authHeaders(false) });
        const questions = await safeJson(res);

        questions?.forEach(q => {
            q.answers?.forEach(a => {
                if (a.id === id) {
                    const span = document.getElementById(`like-count-${id}`);
                    if (span) span.innerText = a.likes;
                }
            });
        });
    } catch (e) {
        console.error(e);
    }
}


// ========================================================================
// ADMIN — PENDING QUESTIONS
// ========================================================================
async function loadPendingQuestions() {
    const box = document.getElementById("pendingQuestions");
    if (!box) return;

    try {
        const res = await fetch(`${QA_BASE}/admin/questions/pending`, {
            headers: authHeaders(false)
        });

        const data = await safeJson(res);

        if (!data || data.length === 0) {
            box.innerHTML = "<p class='text-secondary'>No pending questions.</p>";
            return;
        }

        box.innerHTML = data
            .map(q => `
                <div class="question-card border-start border-warning border-4">
                    <h5>${escapeHtml(q.title)}
                        <span class="badge bg-warning ms-2">Pending</span>
                    </h5>
                    <p>${escapeHtml(q.content)}</p>
                    <p class="question-meta">
                        User: ${escapeHtml(q.username || "Unknown")}
                    </p>

                    <button class="btn btn-success btn-pill me-2"
                        onclick="approveQuestion(${q.id})">
                        Approve
                    </button>

                    <button class="btn btn-danger btn-pill"
                        onclick="adminDeleteQuestion(${q.id})">
                        Delete
                    </button>
                </div>
            `)
            .join("");

    } catch (e) {
        console.error(e);
    }
}

async function approveQuestion(id) {
    await fetch(`${QA_BASE}/admin/questions/${id}/approve`, {
        method: "PUT",
        headers: authHeaders(false)
    });
    location.reload();
}


// ========================================================================
// ADMIN — PENDING ANSWERS
// ========================================================================
async function loadPendingAnswers() {
    const box = document.getElementById("pendingAnswers");
    if (!box) return;

    try {
        const res = await fetch(`${QA_BASE}/admin/answers/pending`, {
            headers: authHeaders(false)
        });

        const data = await safeJson(res);

        if (!data || data.length === 0) {
            box.innerHTML = "<p class='text-secondary'>No pending answers.</p>";
            return;
        }

        box.innerHTML = data
            .map(a => `
                <div class="answer-card border-start border-info border-4">
                    <p>${escapeHtml(a.content)}</p>
                    <p class="question-meta">
                        User: ${escapeHtml(a.username || "Unknown")}
                    </p>

                    <button class="btn btn-success btn-pill me-2"
                        onclick="approveAnswer(${a.id})">
                        Approve
                    </button>

                    <button class="btn btn-danger btn-pill"
                        onclick="adminDeleteAnswer(${a.id})">
                        Delete
                    </button>
                </div>
            `)
            .join("");

    } catch (e) {
        console.error(e);
    }
}

async function approveAnswer(id) {
    await fetch(`${QA_BASE}/admin/answers/${id}/approve`, {
        method: "PUT",
        headers: authHeaders(false)
    });

    location.reload();
}


// ========================================================================
// ADMIN — DELETE QUESTION / ANSWER / CLOSE DISCUSSION
// ========================================================================
async function adminDeleteQuestion(id) {
    if (!confirm("Delete this question?")) return;

    await fetch(`${QA_BASE}/admin/questions/${id}`, {
        method: "DELETE",
        headers: authHeaders(false)
    });

    alert("Question deleted");
    location.reload();
}

async function adminDeleteAnswer(id) {
    if (!confirm("Delete this answer?")) return;

    await fetch(`${QA_BASE}/admin/answers/${id}`, {
        method: "DELETE",
        headers: authHeaders(false)
    });

    alert("Answer deleted");
    location.reload();
}

async function adminCloseQuestion(id) {
    await fetch(`${ADMIN_BASE}/discussions/${id}/close`, {
        method: "PUT",
        headers: authHeaders(false)
    });

    alert("Question marked as resolved");
    location.reload();
}


// ========================================================================
// ADMIN — USERS LIST
// ========================================================================
async function loadAllUsers() {
    const box = document.getElementById("adminUsersTable");
    if (!box) return;

    try {
        const res = await fetch(`${ADMIN_BASE}/users`, {
            headers: authHeaders(false)
        });

        const users = await safeJson(res);

        if (!users || users.length === 0) {
            box.innerHTML = "<p class='text-secondary'>No users found.</p>";
            return;
        }

        box.innerHTML = `
            <table class="table table-dark table-bordered table-striped">
                <thead>
                    <tr>
                        <th>User ID</th>
                        <th>Username</th>
                        <th>Total Questions</th>
                        <th>Status</th>
                        <th>Deactivate</th>
                    </tr>
                </thead>
                <tbody>
        `;

        users.forEach(u => {
            box.innerHTML += `
                <tr>
                    <td>${u.id}</td>
                    <td>${escapeHtml(u.username)}</td>
                    <td>${u.totalQuestions || 0}</td>
                    <td>${
                        u.active
                            ? "<span class='badge bg-success'>Active</span>"
                            : "<span class='badge bg-danger'>Inactive</span>"
                    }</td>
                    <td>
                        <button class="btn btn-sm btn-danger"
                            onclick="deactivateUser(${u.id})">
                            Deactivate
                        </button>
                    </td>
                </tr>
            `;
        });

        box.innerHTML += "</tbody></table>";

    } catch (e) {
        console.error(e);
    }
}

async function deactivateUser(id) {
    await fetch(`${ADMIN_BASE}/users/${id}/deactivate`, {
        method: "PUT",
        headers: authHeaders(false)
    });

    alert("User deactivated");
    loadAllUsers();
}


// ========================================================================
// ADMIN — ANALYTICS
// ========================================================================
let qaChartInstance = null;

async function loadAdminAnalytics() {
    try {
        const res = await fetch(`${ADMIN_BASE}/analytics`, {
            headers: authHeaders(false)
        });

        const data = await safeJson(res) || {};

        const pendingQ = data.pendingQuestions ?? 0;
        const pendingA = data.pendingAnswers ?? 0;
        const totalQ = data.totalQuestions ?? 0;
        const totalA = data.totalAnswers ?? 0;

        document.getElementById("countPendingQuestions").innerText = pendingQ;
        document.getElementById("countPendingAnswers").innerText = pendingA;
        document.getElementById("countTotalQuestions").innerText = totalQ;

        const userRes = await fetch(`${ADMIN_BASE}/users`, { headers: authHeaders(false) });
        const users = await safeJson(userRes);
        document.getElementById("countTotalUsers").innerText = users?.length ?? 0;

    } catch (e) {
        console.error("Analytics load failed", e);
    }
}


// ========================================================================
// ADMIN — LOGS
// ========================================================================
async function loadActivityLog() {
    const box = document.getElementById("activityLog");
    if (!box) return;

    try {
        const res = await fetch(`${ADMIN_BASE}/logs`, {
            headers: authHeaders(false)
        });

        const logs = await safeJson(res);

        if (!logs || logs.length === 0) {
            box.innerHTML = "<p class='text-secondary'>No activity recorded.</p>";
            return;
        }

        box.innerHTML = logs
            .map(l => {
                const action = typeof l === "string" ? l : l.action;
                return `
                    <div class="log-entry">
                        <p><strong>${escapeHtml(action)}</strong></p>
                        <hr/>
                    </div>
                `;
            })
            .join("");

    } catch (e) {
        console.error(e);
    }
}


// ========================================================================
// ADMIN — ALL QUESTIONS PAGE
// ========================================================================
let adminQuestions = [];
let adminFilteredQuestions = [];
let adminCurrentPage = 1;
const ADMIN_PAGE_SIZE = 5;

async function loadAdminAllQuestions() {
    try {
        const approvedRes = await fetch(`${QA_BASE}/questions`, {
            headers: authHeaders(false)
        });

        const pendingRes = await fetch(`${ADMIN_BASE}/questions/pending`, {
            headers: authHeaders(false)
        });

        const approved = await safeJson(approvedRes) || [];
        const pending = await safeJson(pendingRes) || [];

        const merged = [...pending, ...approved];

        adminQuestions = merged.map(q => {
            let cs = !q.approved
                ? "PENDING"
                : q.status === "RESOLVED"
                ? "RESOLVED"
                : "APPROVED";

            return { ...q, computedStatus: cs };
        });

        applyAdminQuestionFilters();

    } catch (e) {
        console.error(e);
    }
}

function applyAdminQuestionFilters() {
    const search = document.getElementById("searchAdminQuestions")?.value.toLowerCase() || "";
    const status = document.getElementById("filterStatus")?.value || "ALL";
    const sort = document.getElementById("sortOrder")?.value || "NEWEST";

    let list = [...adminQuestions];

    if (search) {
        list = list.filter(q =>
            q.title?.toLowerCase().includes(search) ||
            q.content?.toLowerCase().includes(search) ||
            q.username?.toLowerCase().includes(search)
        );
    }

    if (status !== "ALL") list = list.filter(q => q.computedStatus === status);

    list.sort((a, b) => {
        const da = new Date(a.createdAt || 0);
        const db = new Date(b.createdAt || 0);
        return sort === "NEWEST" ? db - da : da - db;
    });

    adminFilteredQuestions = list;
    adminCurrentPage = 1;
    renderAdminQuestionsPage();
}

function renderAdminQuestionsPage() {
    const container = document.getElementById("allQuestionsAdmin");
    const paginationBox = document.getElementById("adminPagination");
    if (!container) return;

    container.innerHTML = "";

    if (adminFilteredQuestions.length === 0) {
        container.innerHTML = "<p class='text-secondary'>No questions found.</p>";
        paginationBox.innerHTML = "";
        return;
    }

    const totalPages = Math.ceil(adminFilteredQuestions.length / ADMIN_PAGE_SIZE);
    const start = (adminCurrentPage - 1) * ADMIN_PAGE_SIZE;
    const pageItems = adminFilteredQuestions.slice(start, start + ADMIN_PAGE_SIZE);

    pageItems.forEach(q => {
        let badgeClass =
            q.computedStatus === "PENDING" ? "bg-warning" :
            q.computedStatus === "RESOLVED" ? "bg-success" :
            "bg-info";

        container.innerHTML += `
            <div class="question-card">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h5>
                            ${escapeHtml(q.title)}
                            <span class="badge ${badgeClass} ms-2">${q.computedStatus}</span>
                        </h5>
                        <p>${escapeHtml(q.content)}</p>
                        <p class="question-meta">
                            User: ${escapeHtml(q.username || "Unknown")}
                        </p>
                    </div>

                    <div class="text-end">
                        <button class="btn btn-sm btn-success mb-2"
                            onclick="adminCloseQuestion(${q.id})">
                            Resolve
                        </button>
                        <br/>
                        <button class="btn btn-sm btn-danger"
                            onclick="adminDeleteQuestion(${q.id})">
                            Delete
                        </button>
                    </div>
                </div>
            </div>
        `;
    });

    paginationBox.innerHTML = generatePagination(totalPages);
}

function generatePagination(totalPages) {
    let html = `<nav><ul class="pagination pagination-sm justify-content-center">`;

    html += `
        <li class="page-item ${adminCurrentPage === 1 ? "disabled" : ""}">
            <button class="page-link" onclick="setAdminPage(${adminCurrentPage - 1})">
                &laquo;
            </button>
        </li>
    `;

    for (let p = 1; p <= totalPages; p++) {
        html += `
            <li class="page-item ${p === adminCurrentPage ? "active" : ""}">
                <button class="page-link" onclick="setAdminPage(${p})">${p}</button>
            </li>
        `;
    }

    html += `
        <li class="page-item ${adminCurrentPage === totalPages ? "disabled" : ""}">
            <button class="page-link" onclick="setAdminPage(${adminCurrentPage + 1})">
                &raquo;
            </button>
        </li>
    `;

    html += `</ul></nav>`;
    return html;
}

function setAdminPage(page) {
    const totalPages = Math.ceil(adminFilteredQuestions.length / ADMIN_PAGE_SIZE);
    if (page < 1 || page > totalPages) return;
    adminCurrentPage = page;
    renderAdminQuestionsPage();
}


// ========================================================================
// INIT ALL ADMIN OPS
// ========================================================================
function initAdminOps() {
    loadPendingQuestions();
    loadPendingAnswers();
    loadAllUsers();
    loadActivityLog();
    loadAdminAnalytics();
    loadAdminAllQuestions();
}  