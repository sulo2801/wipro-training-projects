package com.doconnect.qaservice.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.doconnect.qaservice.security.JwtAuthenticationFilter;

@Configuration
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http.csrf(cs -> cs.disable());

        http.sessionManagement(ss ->
                ss.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
        );

        http.authorizeHttpRequests(auth -> auth

                // Public read-access
                .requestMatchers(HttpMethod.GET, "/qa/questions").permitAll()
                .requestMatchers(HttpMethod.GET, "/qa/questions/*/answers").permitAll()

                // Authenticated user actions
                .requestMatchers(HttpMethod.POST, "/qa/questions").authenticated()
                .requestMatchers(HttpMethod.POST, "/qa/answers").authenticated()

                // Admin operations
                .requestMatchers("/qa/admin/**").hasRole("ADMIN")

                // Everything else requires authentication
                .anyRequest().authenticated()
        );

        // Important: Add our custom JWT filter
        http.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
