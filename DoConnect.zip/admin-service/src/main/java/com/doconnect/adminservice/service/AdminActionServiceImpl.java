package com.doconnect.adminservice.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.doconnect.adminservice.dto.UserAdminResponse;
import com.doconnect.adminservice.security.AdminJwtContext;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AdminActionServiceImpl implements AdminActionService {

    private final RestTemplate restTemplate;

    @Value("${services.user-service.base-url:http://localhost:8081}")
    private String userServiceBaseUrl;

    @Value("${services.qa-service.base-url:http://localhost:8082}")
    private String qaServiceBaseUrl;

    private HttpHeaders authHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        String token = AdminJwtContext.getToken();
        if (token != null) headers.set("Authorization", "Bearer " + token);
        return headers;
    }

    // ============================= USERS ===================================
    @Override
    public List<UserAdminResponse> getAllUsers() {
        String url = userServiceBaseUrl + "/auth/admin/users";
        ResponseEntity<UserAdminResponse[]> response =
                restTemplate.getForEntity(url, UserAdminResponse[].class);

        return response.getBody() == null ? List.of() : Arrays.asList(response.getBody());
    }

    @Override
    public String deactivateUser(Long userId) {
        String url = userServiceBaseUrl + "/auth/admin/users/" + userId + "/deactivate";
        restTemplate.exchange(url, HttpMethod.PUT, new HttpEntity<>(authHeaders()), Void.class);
        return "User deactivated successfully";
    }

    // ============================= QUESTIONS ==================================
    @Override
    public String approveQuestion(Long questionId) {
        String url = qaServiceBaseUrl + "/qa/admin/questions/" + questionId + "/approve";
        restTemplate.exchange(url, HttpMethod.PUT, new HttpEntity<>(authHeaders()), Void.class);
        return "Question approved successfully";
    }

    @Override
    public String deleteQuestion(Long questionId) {
        String url = qaServiceBaseUrl + "/qa/questions/" + questionId;
        restTemplate.exchange(url, HttpMethod.DELETE, new HttpEntity<>(authHeaders()), Void.class);
        return "Question deleted successfully";
    }

    @Override
    public String closeDiscussion(Long questionId) {
        String url = qaServiceBaseUrl + "/qa/admin/discussions/" + questionId + "/close";
        restTemplate.exchange(url, HttpMethod.PUT, new HttpEntity<>(authHeaders()), Void.class);
        return "Discussion closed successfully";
    }

    // ============================= ANSWERS =====================================
    @Override
    public String approveAnswer(Long answerId) {
        String url = qaServiceBaseUrl + "/qa/admin/answers/" + answerId + "/approve";
        restTemplate.exchange(url, HttpMethod.PUT, new HttpEntity<>(authHeaders()), Void.class);
        return "Answer approved successfully";
    }

    @Override
    public String deleteAnswer(Long answerId) {
        String url = qaServiceBaseUrl + "/qa/answers/" + answerId;
        restTemplate.exchange(url, HttpMethod.DELETE, new HttpEntity<>(authHeaders()), Void.class);
        return "Answer deleted successfully";
    }

    // ============================= PENDING ======================================
    @Override
    public String getPendingQuestions() {
        String url = qaServiceBaseUrl + "/qa/admin/questions/pending";
        return restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(authHeaders()), String.class).getBody();
    }

    @Override
    public String getPendingAnswers() {
        String url = qaServiceBaseUrl + "/qa/admin/answers/pending";
        return restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(authHeaders()), String.class).getBody();
    }

    // ============================= ANALYTICS ====================================
    @Override
    public String getAnalytics() {
        String url = qaServiceBaseUrl + "/qa/admin/analytics";
        return restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(authHeaders()), String.class).getBody();
    }

    // ============================= LOGS =========================================
    @Override
    public String getActivityLog() {
        String url = qaServiceBaseUrl + "/qa/admin/logs";
        return restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(authHeaders()), String.class).getBody();
    }
}
