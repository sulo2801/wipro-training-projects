package com.doconnect.qaservice.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class JwtUtil {

    @Value("${jwt.secret}")
    private String secret;

    // ---------------------------------------
    //  SECRET KEY for verifying JWT signature
    // ---------------------------------------
    private SecretKey getKey() {
        return Keys.hmacShaKeyFor(secret.getBytes());
    }

    // ---------------------------------------
    //  Extract username (subject) from token
    //  For USERS → this is userId
    //  For ADMIN → this is admin email/username
    // ---------------------------------------
    public String extractUsername(String token) {
        return extractClaims(token).getSubject();
    }

    // ---------------------------------------
    // Extract ADMIN roles correctly
    
    // ---------------------------------------
    public List<String> extractRoles(String token) {
        return extractClaims(token).get("roles", List.class);
    }

    // ---------------------------------------
    //  Get ALL claims inside the JWT
    // ---------------------------------------
    public Claims extractClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getKey())     // Verify signature
                .build()
                .parseClaimsJws(token)       // Parse + Validate token
                .getBody();                  // Return payload
    }
}
