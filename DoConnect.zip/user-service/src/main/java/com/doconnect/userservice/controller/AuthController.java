package com.doconnect.userservice.controller;

import com.doconnect.userservice.dto.*;
import com.doconnect.userservice.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final UserService service;

    @PostMapping("/register")
    public AuthResponse register(@RequestBody RegisterRequest req) {
        return service.register(req);
    }

    @PostMapping("/login")
    public AuthResponse login(@RequestBody LoginRequest req) {
        return service.login(req);
    }
    
    @GetMapping("/user/{id}")
    public UserResponse getUserById(@PathVariable Long id) {
        return service.getUserById(id);
    }


    @PostMapping("/logout")
    public String logout(@RequestHeader(value = "Authorization", required = false) String token) {

        if (token == null || !token.startsWith("Bearer ")) {
            return "Invalid Token";
        }

        String jwt = token.substring(7);
        service.logout(jwt);

        return "Logged out successfully";
    }

}
