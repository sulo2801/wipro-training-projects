package com.doconnect.adminservice.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.doconnect.adminservice.dto.AuthResponse;
import com.doconnect.adminservice.dto.LoginRequest;
import com.doconnect.adminservice.dto.RegisterRequest;
import com.doconnect.adminservice.service.AdminService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/admin/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AdminService adminService;

    @PostMapping("/register")
    public ResponseEntity<Map<String, String>> register(@RequestBody RegisterRequest request) {
        adminService.register(request);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Admin registered successfully");

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }


    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@RequestBody LoginRequest request) {
        AuthResponse response = adminService.login(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logout() {
        // With JWT, logout is handled by client (delete token)
        return ResponseEntity.ok("Logout successful. Please delete token on client.");
    }
}
