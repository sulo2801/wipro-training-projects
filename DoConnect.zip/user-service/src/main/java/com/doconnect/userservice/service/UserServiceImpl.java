package com.doconnect.userservice.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.doconnect.userservice.dto.AuthResponse;
import com.doconnect.userservice.dto.LoginRequest;
import com.doconnect.userservice.dto.RegisterRequest;
import com.doconnect.userservice.dto.UserResponse;
import com.doconnect.userservice.dto.UserAdminResponse;
import com.doconnect.userservice.entity.User;
import com.doconnect.userservice.repository.UserRepository;
import com.doconnect.userservice.security.JwtUtil;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository repo;
    private final BCryptPasswordEncoder encoder;
    private final JwtUtil jwtUtil;

    // Token blacklist for logout
    private final Set<String> blacklist = new HashSet<>();

    // =====================================================
    // REGISTER
    // =====================================================
    @Override
    public AuthResponse register(RegisterRequest req) {

        User user = User.builder()
                .username(req.getUsername())
                .password(encoder.encode(req.getPassword()))
                .role(req.getRole()) // "USER" or "ADMIN"
                .active(true)
                .build();

        repo.save(user);

        String token = jwtUtil.generateToken(user.getId(), user.getUsername(), user.getRole());

        return new AuthResponse(token, "User Registered Successfully");
    }

    @Override
    public AuthResponse login(LoginRequest req) {

        User user = repo.findByUsername(req.getUsername())
                .orElseThrow(() -> new RuntimeException("User Not Found"));

        if (!encoder.matches(req.getPassword(), user.getPassword()))
            throw new RuntimeException("Invalid Credentials");

        String token = jwtUtil.generateToken(user.getId(), user.getUsername(), user.getRole());

        return new AuthResponse(token, "Login Successful");
    }

    // =====================================================
    // LOGOUT
    // =====================================================
    @Override
    public void logout(String token) {
        blacklist.add(token);
    }

    // =====================================================
    // TOKEN VALIDATION
    // =====================================================
    @Override
    public void loadUser(String username) {
        repo.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Invalid Token User"));
    }

    // =====================================================
    // GET USER BY ID
    // =====================================================
    @Override
    public UserResponse getUserById(Long id) {

        User user = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        return new UserResponse(
                user.getId(),
                user.getUsername(),
                user.getRole()
        );
    }

    // =====================================================
    // ⭐ ADMIN — GET ALL USERS
    // =====================================================
    @Override
    public List<UserAdminResponse> getAllUsersForAdmin() {

        return repo.findAll()
                .stream()
                .map(u -> new UserAdminResponse(
                        u.getId(),
                        u.getUsername(),
                        u.isActive(),
                        0L  // since questions belong to qa-service, not here
                ))
                .collect(Collectors.toList());
    }

    // =====================================================
    // ⭐ ADMIN — DEACTIVATE USER
    // =====================================================
    @Override
    public void deactivateUser(Long id) {

        User user = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setActive(false);
        repo.save(user);
    }
}
