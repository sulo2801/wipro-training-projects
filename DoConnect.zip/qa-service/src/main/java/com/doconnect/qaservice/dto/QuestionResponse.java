package com.doconnect.qaservice.dto;

import java.time.LocalDateTime;

import com.doconnect.qaservice.entity.QuestionStatus;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class QuestionResponse {

    private Long id;
    private String title;
    private String content;

    private String userId;   // stored as string in DB
    private String username; // fetched via FEIGN

    private LocalDateTime createdAt;

    private QuestionStatus status;
    private boolean approved;
    private boolean active;
}
