package com.doconnect.apigateway.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UIController {

    // ---------- HOME ----------
    @GetMapping("/")
    public String home() {
        return "index";
    }

    // ---------- USER PAGES ----------
    @GetMapping("/login")
    public String userLogin() {
        return "login";
    }

    @GetMapping("/register")
    public String userRegister() {
        return "register";
    }

    @GetMapping("/dashboard")
    public String userDashboard() {
        return "dashboard";
    }

    @GetMapping("/ask-question")
    public String askQuestion() {
        return "ask-question";
    }

    @GetMapping("/view-questions")
    public String viewQuestions() {
        return "view-questions";
    }
    
    @GetMapping("/answer-question")
    public String answerQuestion() {
        return "answer-question";
    }


    // ---------- ADMIN PAGES ----------
    @GetMapping("/admin/login")
    public String adminLogin() {
        return "admin-login";
    }

    @GetMapping("/admin/register")
    public String adminRegister() {
        return "admin-register";
    }

    @GetMapping("/admin/dashboard")
    public String adminDashboard() {
        return "admin-dashboard";
    }

    @GetMapping("/admin/approve-questions")
    public String approveQuestions() {
        return "approve-questions";
    }

    @GetMapping("/admin/approve-answers")
    public String approveAnswers() {
        return "approve-answers";
    }
    @GetMapping("/admin/admin-operations")
    public String adminOperations() {
        return "admin-operations";
    }
}
