package com.doconnect.adminservice.dto;

import lombok.Data;

@Data
public class AdminAnalyticsResponse {
    private long pendingQuestions;
    private long pendingAnswers;
    private long totalUsers;
    private long totalQuestions;
}
