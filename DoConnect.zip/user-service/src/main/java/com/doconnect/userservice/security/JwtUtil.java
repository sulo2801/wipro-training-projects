package com.doconnect.userservice.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.List;

@Component
public class JwtUtil {

    @Value("${jwt.secret}")
    private String secret;

    @Value("${jwt.expiration}")
    private long expiry;

    // --------------------------------------------------------------
    // Generate secret key from application property (HMAC SHA-256)
    // --------------------------------------------------------------
    private SecretKey getKey() {
        return Keys.hmacShaKeyFor(secret.getBytes());
    }

    // =======================================================================
    // ⭐ GENERATE JWT FOR USER
    // =======================================================================
    // IMPORTANT:
    // User tokens originally contained:   "role": "USER"
    // Admin tokens contain:               "roles": ["ROLE_ADMIN"]
    //
    // QA-Service expects *both* tokens to provide a "roles" array.
    // So we now include:
    //   1. "role"  → backward compatibility
    //   2. "roles" → preferred format for all services
    //
    // =======================================================================
    public String generateToken(Long id, String username, String role) {

        // Ensure Spring Security compatible format: "USER" → "ROLE_USER"
        String finalRole = role.startsWith("ROLE_") ? role : "ROLE_" + role;

        return Jwts.builder()
                // "sub" → username of user
                .setSubject(username)

                // Store user ID explicitly
                .claim("id", id)

                // Old-style role (used by older components, safe to keep)
                .claim("role", role)

                // ⭐ New-style roles array (same format as Admin tokens)
                .claim("roles", List.of(finalRole))

                // Token lifetime settings
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expiry))

                // Signing algorithm
                .signWith(getKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    // =======================================================================
    // Extract ALL claims from token
    // =======================================================================
    public Claims extractAllClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getKey())    // verify signature
                .build()
                .parseClaimsJws(token)
                .getBody();                 // return payload
    }

    // =======================================================================
    // Extract username (subject)
    // =======================================================================
    public String extractUsername(String token) {
        return extractAllClaims(token).getSubject();
    }

    // =======================================================================
    // Extract stored user ID
    // =======================================================================
    public Long extractUserId(String token) {
        return extractAllClaims(token).get("id", Long.class);
    }

    // =======================================================================
    // Extract old-style single role ("USER")
    // Only used for backward compatibility.
    // =======================================================================
    public String extractRole(String token) {
        return extractAllClaims(token).get("role", String.class);
    }

    // =======================================================================
    // ⭐ Extract new-style roles ARRAY (["ROLE_USER"])
    // Used by QA-Service / API Gateway / Microservice Security
    // =======================================================================
    public List<String> extractRoles(String token) {
        return extractAllClaims(token).get("roles", List.class);
    }
}
