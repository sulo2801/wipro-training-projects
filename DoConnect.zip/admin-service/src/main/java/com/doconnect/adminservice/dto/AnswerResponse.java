package com.doconnect.adminservice.dto;

import lombok.Data;

@Data
public class AnswerResponse {
    private Long id;
    private Long questionId;
    private String content;
    private String userId;
    private boolean approved;
    private boolean active;
    private String createdAt;
    private int likes;
}
