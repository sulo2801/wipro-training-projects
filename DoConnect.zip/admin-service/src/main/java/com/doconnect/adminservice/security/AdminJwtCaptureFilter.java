package com.doconnect.adminservice.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class AdminJwtCaptureFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        // Read Authorization header from the incoming request
        String header = request.getHeader("Authorization");

        // If JWT exists and starts with "Bearer "
        if (header != null && header.startsWith("Bearer ")) {

            // Extract only the token part
            String token = header.substring(7);

            // Save token in ThreadLocal (AdminJwtContext)
            // → Used later inside services or downstream calls
            AdminJwtContext.setToken(token);
        }

        try {
            // Continue filter chain execution
            filterChain.doFilter(request, response);

        } finally {
            // Clean up ThreadLocal to avoid memory leaks
            AdminJwtContext.clear();
        }
    }
}
