package com.doconnect.apigateway.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityWebFilterChain filterChain(ServerHttpSecurity http) {

        http
            .csrf(ServerHttpSecurity.CsrfSpec::disable)
            .authorizeExchange(ex -> ex
                .pathMatchers(
                        "/", "/index", "/index.html",

                        // static frontend files
                        "/css/**", "/js/**", "/images/**", "/frontend/**",

                        // user service
                        "/auth/**",

                        // admin UI pages (HTML only)
                        "/admin/**",

                        "/admin/dashboard",
                        "/admin/admin-operations.html",
                        "/admin/approve-questions.html",
                        "/admin/approve-answers.html",
                        "/admin/login.html",
                        "/admin/register.html",

                        // QA service
                        "/qa/**",

                        // Eureka dashboard
                        "/eureka/**"
                ).permitAll()

                // Everything else allowed (Gateway does NOT block)
                .anyExchange().permitAll()
            )
            .httpBasic(ServerHttpSecurity.HttpBasicSpec::disable)
            .formLogin(ServerHttpSecurity.FormLoginSpec::disable);

        return http.build();
    }
}
