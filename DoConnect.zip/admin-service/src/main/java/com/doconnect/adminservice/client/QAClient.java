package com.doconnect.adminservice.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.doconnect.adminservice.dto.AnswerResponse;
import com.doconnect.adminservice.dto.QuestionResponse;

@FeignClient(name = "QA-SERVICE")
public interface QAClient {

    // 🔹 Fetch pending questions
    @GetMapping("/qa/admin/questions/pending")
    List<QuestionResponse> getPendingQuestions();

    // 🔹 Fetch pending answers
    @GetMapping("/qa/admin/answers/pending")
    List<AnswerResponse> getPendingAnswers();

    // 🔹 Approve a question
    @PutMapping("/qa/admin/questions/{id}/approve")
    String approveQuestion(@PathVariable Long id);

    // 🔹 Approve an answer
    @PutMapping("/qa/admin/answers/{id}/approve")
    String approveAnswer(@PathVariable Long id);

    // 🔹 Delete a question
    @DeleteMapping("/qa/questions/{id}")
    String deleteQuestion(@PathVariable Long id);

    // 🔹 Delete an answer
    @DeleteMapping("/qa/answers/{id}")
    String deleteAnswer(@PathVariable Long id);

    // 🔹 Close a discussion
    @PutMapping("/qa/questions/{id}/close")
    String closeDiscussion(@PathVariable Long id);
}
