package com.doconnect.qaservice.dto;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AnswerResponse {

    private Long id;
    private Long questionId;

    private String content;

    private String userId;
    private String username;

    private LocalDateTime createdAt;

    private boolean approved;
    private boolean active;

    private Integer likes;   // use Integer to avoid null issues
}
