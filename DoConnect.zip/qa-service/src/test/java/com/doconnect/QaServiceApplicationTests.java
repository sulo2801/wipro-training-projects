package com.doconnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
