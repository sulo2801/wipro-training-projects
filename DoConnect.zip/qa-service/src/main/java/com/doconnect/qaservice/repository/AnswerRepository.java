package com.doconnect.qaservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.doconnect.qaservice.entity.Answer;

public interface AnswerRepository extends JpaRepository<Answer, Long> {

    // Only show answers that are active + approved
    List<Answer> findByQuestionIdAndActiveTrue(Long id);

    // For admin - pending answers
    List<Answer> findByApprovedFalseAndActiveTrue();

    long countByApprovedFalseAndActiveTrue();
}
